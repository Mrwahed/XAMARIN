﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace CoreDataBindingDemos
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class OneWayToSourceBinding : ContentPage
    {
        Car c = null;
        public OneWayToSourceBinding()
        {
            InitializeComponent();
            c = new Car();

            this.BindingContext = c;
        }

        private void CreateFordCar(object sender, EventArgs e)
        {
            c.CarId = 1000;
            c.Brand = "FORD";
            c.Model = "Figo Asipre";
            c.Year = 2020;
            carimage.Source = "fordaspire.jpg";
            DisplayAlert("Success", "Created", "OK");
        }

        private void CreateHyundaiCar(object sender, EventArgs e)
        {
            c.CarId = 2000;
            c.Brand = "HYUNDAI";
            c.Model = "Creta";
            c.Year = 2021;
            carimage.Source = "hyundaicreta.jpg";
            DisplayAlert("Success", "Created", "OK");
        }

        private void CreateRolsRoyceCar(object sender, EventArgs e)
        {
            c.CarId = 3000;
            c.Brand = "ROLS ROYCE";
            c.Model = "Phantom";
            c.Year = 2017;
            carimage.Source = "rolsroycephantom.jpg";
            DisplayAlert("Success", "Created", "OK");
        }

        private void ShowCurrentCar(object sender, EventArgs e)
        {
            string details = "Car Id: " + this.c.CarId + "\n";
            details += "Brand: " + this.c.Brand + "\n";
            details += "Model: " + this.c.Model + "\n";
            details += "Photo Name: " + this.c.Photo;
            DisplayAlert("Car Details", details, "OK");
        }
    }
}