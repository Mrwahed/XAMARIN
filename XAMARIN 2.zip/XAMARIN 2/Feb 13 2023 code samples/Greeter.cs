﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace CoreDataBindingDemos
{
    internal class Greeter : INotifyPropertyChanged
    {
        private string message;

        public string GreetingMessage
        {
            get
            {
                return this.message;
            }
            set
            {
                this.message = value;

                //raise the event
                if (PropertyChanged != null)
                {
                    PropertyChanged(this, new PropertyChangedEventArgs("GreetingMessage"));
                }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }
}
