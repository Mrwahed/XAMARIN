﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CoreDataBindingDemos
{
    internal class Car
    {
        public int CarId { get; set; }
        public string Brand { get; set; }
        public string Model { get; set; }
        public string Photo { get; set; }
        public int Year { get; set; }
    }
}
