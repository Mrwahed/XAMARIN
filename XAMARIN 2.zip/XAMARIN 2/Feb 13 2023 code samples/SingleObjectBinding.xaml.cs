﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace CoreDataBindingDemos
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class SingleObjectBinding : ContentPage
    {
        //create a Car instance
        Car c = null;
        public SingleObjectBinding()
        {
            InitializeComponent();
            c = new Car
            {
                CarId = 1,
                Brand = "FORD",
                Model = "Figo Aspire",
                Year = 2018,
                Photo = "fordaspire.png"
            };

            //set the binding context of the page
            this.BindingContext = c;
        }
    }
}