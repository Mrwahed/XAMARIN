﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace CoreDataBindingDemos
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class TwoWayBinding : ContentPage
    {
        Greeter g = null;
        public TwoWayBinding()
        {
            InitializeComponent();

            g = new Greeter();
            g.GreetingMessage = "NONE";
            this.BindingContext = g;
        }

        private void DisplayGreetingMessage(object sender, EventArgs e)
        {
            DisplayAlert("Greeting Message", this.g.GreetingMessage, "Ok");
        }

        private void ChangeGreetingMessage(object sender, EventArgs e)
        {
            greetingmessagelabel.Text = "Good Morning";
        }
    }
}