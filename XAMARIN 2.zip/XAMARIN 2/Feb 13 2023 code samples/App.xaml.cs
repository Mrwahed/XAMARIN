﻿using System;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace CoreDataBindingDemos
{
    public partial class App : Application
    {
        public App()
        {
            InitializeComponent();

            //MainPage = new SingleObjectBinding();
            //MainPage = new ViewToViewBinding();
            //MainPage = new ViewToViewBindingDemo1();
            //MainPage = new OneTimeBinding();
            //MainPage = new OneWayBinding();
            MainPage = new TwoWayBinding();
            //MainPage = new OneWayToSourceBinding();
            //MainPage = new ListViewDemo1();
            //MainPage = new ListViewDemoWithObservableCollection();
        }

        protected override void OnStart()
        {
        }

        protected override void OnSleep()
        {
        }

        protected override void OnResume()
        {
        }
    }
}
