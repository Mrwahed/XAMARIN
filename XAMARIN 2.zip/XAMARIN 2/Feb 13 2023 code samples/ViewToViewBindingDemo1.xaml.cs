﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace CoreDataBindingDemos
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ViewToViewBindingDemo1 : ContentPage
    {
        public ViewToViewBindingDemo1()
        {
            InitializeComponent();
        }

        private void ChangeLabelText(object sender, EventArgs e)
        {
            label1.Text = "LABEL TEXT CHANGED";
        }
    }
}