﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace CoreDataBindingDemos
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class OneWayBinding : ContentPage
    {
        Greeter g = null;
        public OneWayBinding()
        {
            InitializeComponent();
            g = new Greeter
            {
                GreetingMessage = "NONE"
            };
            this.BindingContext = g;
        }

        private void GreetGoodMorning(object sender, EventArgs e)
        {
            this.g.GreetingMessage = "Good Morning";
        }

        private void GreetGoodAfternoon(object sender, EventArgs e)
        {
            this.g.GreetingMessage = "Good Afternoon";
        }

        private void GreetGoodNight(object sender, EventArgs e)
        {
            this.g.GreetingMessage = "Good Night";
        }
    }
}