﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace CoreDataBindingDemos
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class OneTimeBinding : ContentPage
    {
        Car c1 = null;
        Car c2 = null;
        public OneTimeBinding()
        {
            InitializeComponent();

            c1 = new Car
            {
                CarId = 1,
                Brand = "ROLS ROYCE",
                Model = "Phantom",
                Year = 2019,
                Photo = "rolsroycephantom.jpg"
            };

            c2 = new Car
            {
                CarId = 2,
                Brand = "WOLKS WAGON",
                Model = "Polo",
                Year = 2013,
                Photo = "wolkswagonpolo.jpg"
            };

            this.BindingContext = c1;
        }

        private void ChangeBindingContext(object sender, EventArgs e)
        {
            this.BindingContext = c2;
        }
    }
}