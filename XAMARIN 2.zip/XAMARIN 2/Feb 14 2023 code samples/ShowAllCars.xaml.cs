﻿using CarsMVVMExample.Models;
using CarsMVVMExample.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace CarsMVVMExample.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ShowAllCars : ContentPage
    {
        ShowCarsVM vm = new ShowCarsVM();
        public ShowAllCars()
        {
            InitializeComponent();

            this.BindingContext = vm;
        }

        private void DisplayDetails(object sender, ItemTappedEventArgs e)
        {
            Car c = (Car)e.Item;
            DisplayAlert("Car Details", c.Brand + " released this model in the year " + c.Year, "OK");
        }
    }
}